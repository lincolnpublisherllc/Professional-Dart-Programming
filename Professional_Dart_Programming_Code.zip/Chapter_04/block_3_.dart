Tries (Prefix Trees)
Used for fast text searches (autocomplete, spell-check).
class TrieNode {
  final Map<String, TrieNode> children = {};
  bool isEndOfWord = false;
}

class Trie {
  final TrieNode root = TrieNode();

  void insert(String word) {
    var node = root;
    for (var char in word.split('')) {
      node = node.children.putIfAbsent(char, () => TrieNode());
    }
    node.isEndOfWord = true;
  }

  bool search(String word) {
    var node = root;
    for (var char in word.split('')) {
      if (!node.children.containsKey(char)) return false;
      node = node.children[char]!;
    }
    return node.isEndOfWord;
  }
}

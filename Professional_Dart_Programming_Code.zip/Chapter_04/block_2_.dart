class MinHeap {
  final List<int> _heap = [];

  void insert(int value) {
    _heap.add(value);
    _bubbleUp(_heap.length - 1);
  }

  int extractMin() {
    if (_heap.isEmpty) throw StateError('Heap empty');
    final min = _heap.first;
    _heap[0] = _heap.removeLast();
    _bubbleDown(0);
    return min;
  }

  void _bubbleUp(int index) {
    while (index > 0) {
      final parent = (index - 1) ~/ 2;
      if (_heap[index] < _heap[parent]) {
        _swap(index, parent);
        index = parent;
      } else break;
    }
  }

  void _bubbleDown(int index) {
    final last = _heap.length - 1;
    while (true) {
      final left = 2 * index + 1;
      final right = 2 * index + 2;
      int smallest = index;

      if (left <= last && _heap[left] < _heap[smallest]) smallest = left;
      if (right <= last && _heap[right] < _heap[smallest]) smallest = right;

      if (smallest != index) {
        _swap(index, smallest);
        index = smallest;
      } else break;
    }
  }

  void _swap(int i, int j) {
    final temp = _heap[i];
    _heap[i] = _heap[j];
    _heap[j] = temp;
  }
}

class Graph {
  final Map<String, List<String>> _adjacency = {};

  void addEdge(String from, String to) {
    _adjacency.putIfAbsent(from, () => []).add(to);
    _adjacency.putIfAbsent(to, () => []); // ensure node exists
  }

  List<String> neighbors(String node) => _adjacency[node] ?? [];
}

void main() {
  var g = Graph();
  g.addEdge('A', 'B');
  g.addEdge('A', 'C');
  g.addEdge('B', 'D');

  print(g.neighbors('A')); // [B, C]
}

Breadth-First Search (BFS)

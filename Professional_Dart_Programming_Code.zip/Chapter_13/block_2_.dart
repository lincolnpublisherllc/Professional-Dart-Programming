Integration tests validate multiple modules together (e.g., API + DB).
import 'package:test/test.dart';
import 'package:postgres/postgres.dart';

void main() {
  test('database connection works', () async {
    final connection = PostgreSQLConnection('localhost', 5432, 'testdb');
    await connection.open();
    expect(connection.isClosed, isFalse);
    await connection.close();
  });
}

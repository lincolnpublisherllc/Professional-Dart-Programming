import 'package:benchmark_harness/benchmark_harness.dart';

class MyBenchmark extends BenchmarkBase {
  MyBenchmark() : super('MyBenchmark');

  void run() {
    var sum = 0;
    for (var i = 0; i < 1000000; i++) sum += i;
  }
}

void main() {
  MyBenchmark().report();
}

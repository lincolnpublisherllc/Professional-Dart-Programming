import 'package:dart_jsonwebtoken/dart_jsonwebtoken.dart';

String generateToken(String userId) {
  final jwt = JWT({'id': userId}, issuer: 'chat-app');
  return jwt.sign(SecretKey('super_secret_key'));
}

void verifyToken(String token) {
  try {
    final jwt = JWT.verify(token, SecretKey('super_secret_key'));
    print('Payload: ${jwt.payload}');
  } catch (e) {
    print('Invalid token: $e');
  }
}

import 'dart:async';

class ChatRoom {
  final _controller = StreamController<String>.broadcast();

  Stream<String> get messages => _controller.stream;
  void send(String message) => _controller.add(message);
}

void main() {
  final room = ChatRoom();
  room.messages.listen((msg) => print('User1: $msg'));
  room.messages.listen((msg) => print('User2: $msg'));

  room.send('Hello, Dart!');
}

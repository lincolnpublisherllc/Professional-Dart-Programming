import 'package:shelf/shelf.dart';
import 'package:shelf/shelf_io.dart' as io;

void main() async {
  final handler = Pipeline()
      .addMiddleware(logRequests())
      .addHandler((Request req) {
        if (req.url.path.startsWith('users')) {
          return Response.ok('User service placeholder');
        } else if (req.url.path.startsWith('messages')) {
          return Response.ok('Message service placeholder');
        }
        return Response.notFound('Not found');
      });

  await io.serve(handler, 'localhost', 8080);
  print('API Gateway running at http://localhost:8080');
}

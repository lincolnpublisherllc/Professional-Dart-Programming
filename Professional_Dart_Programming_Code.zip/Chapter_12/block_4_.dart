import 'package:dio/dio.dart';

Future<void> sendSms(String number, String text) async {
  final dio = Dio();
  await dio.post('https://sms-provider.com/api/send', data: {

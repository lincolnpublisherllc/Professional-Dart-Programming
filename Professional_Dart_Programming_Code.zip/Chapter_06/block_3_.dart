import 'dart:isolate';

void heavyComputation(SendPort sendPort) {
  var result = 0;
  for (var i = 0; i < 1e8; i++) {
    result += i;
  }
  sendPort.send(result);
}

void main() async {
  final receivePort = ReceivePort();
  await Isolate.spawn(heavyComputation, receivePort.sendPort);

  final result = await receivePort.first;
  print('Result: $result');
}

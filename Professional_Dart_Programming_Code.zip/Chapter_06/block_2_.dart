import 'dart:async';

void main() async {
  final controller = StreamController<int>();

import 'package:dio/dio.dart';
import 'dart:async';

Future<String> fetchPage(String url) async {
  var dio = Dio();
  var response = await dio.get(url);
  return 'Fetched ${response.data.length} chars from $url';
}

Future<void> main() async {

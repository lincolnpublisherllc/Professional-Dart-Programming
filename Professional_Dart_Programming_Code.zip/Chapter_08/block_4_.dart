import 'package:retry/retry.dart';

Future<void> fetchData() async {
  final r = RetryOptions(maxAttempts: 5);
  await r.retry(
    () => dio.get('https://api.example.com'),
    retryIf: (e) => e is DioError,
  );
}

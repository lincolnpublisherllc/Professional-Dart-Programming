Use secrets managers (Vault, AWS Secrets Manager, Google Secret Manager).
import 'dart:io';

void main() {
  final apiKey = Platform.environment['API_KEY'];
  print('Using API key: $apiKey');
}

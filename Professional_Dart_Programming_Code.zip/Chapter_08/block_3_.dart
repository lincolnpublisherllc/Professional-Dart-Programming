import 'package:encrypt/encrypt.dart';

void main() {
  final key = Key.fromUtf8('32charslongsecretkeymustbe!!');
  final iv = IV.fromLength(16);
  final encrypter = Encrypter(AES(key));

  final encrypted = encrypter.encrypt('SensitiveData', iv: iv);
  print(encrypted.base64);

  final decrypted = encrypter.decrypt(encrypted, iv: iv);
  print(decrypted);
}

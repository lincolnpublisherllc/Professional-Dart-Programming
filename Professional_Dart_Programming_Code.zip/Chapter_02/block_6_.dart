import 'dart:mirrors';

class User {
  String name = 'Alice';
}

void main() {
  var user = User();
  var instanceMirror = reflect(user);
  var classMirror = instanceMirror.type;

  print('Class: ${classMirror.simpleName}');
  print('Fields: ${classMirror.declarations.keys}');
}
⚠️ Note: dart:mirrors is not supported in Flutter (size and performance reasons). It’s mainly for server-side or research-level code.

mixin Logger {
  void log(String message) {
    print('[LOG] $message');
  }
}

class Service with Logger {
  void doWork() {
    log('Starting work');
  }
}

class Entity {
  final String tableName;
  const Entity(this.tableName);
}

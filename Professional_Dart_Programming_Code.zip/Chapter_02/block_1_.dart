abstract class Repository<T> {
  void add(T item);
  List<T> getAll();
}

class User {
  final String name;
  User(this.name);
}

class UserRepository extends Repository<User> {
  final _storage = <User>[];

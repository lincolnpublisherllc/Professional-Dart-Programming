class Point {
  final int x, y;
  Point(this.x, this.y);
}

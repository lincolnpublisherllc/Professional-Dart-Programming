sealed class Payment {}
class Cash extends Payment {}
class CreditCard extends Payment {}

void handle(Payment p) {
  switch (p) {
    case Cash():
      print('Cash payment');
    case CreditCard():
      print('Credit card payment');
  }
}

class User with _$User {
  const factory User({

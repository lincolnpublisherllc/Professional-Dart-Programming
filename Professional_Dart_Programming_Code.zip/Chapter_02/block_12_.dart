@Entity('users')
class User {
  final int id;
  final String name;
  User(this.id, this.name);
}

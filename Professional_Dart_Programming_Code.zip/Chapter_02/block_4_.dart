class Vector {
  final double x, y;
  Vector(this.x, this.y);

  Vector operator +(Vector other) => Vector(x + other.x, y + other.y);
}

void main() {
  var v1 = Vector(2, 3);
  var v2 = Vector(1, 1);
  var result = v1 + v2;
  print('${result.x}, ${result.y}'); // 3.0, 4.0
}

5. Sealed Classes & Pattern Matching (Dart 3+)

import 'dart:convert';
import 'dart:io';

void main() async {
  var file = File('log.txt');
  var lineStream = file.openRead()
    .transform(utf8.decoder)
    .transform(const LineSplitter());

  await for (var line in lineStream) {
    if (line.contains('ERROR')) {
      print(line);
    }
  }
}

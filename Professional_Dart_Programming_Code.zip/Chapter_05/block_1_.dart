Example with get_it (popular Dart DI package):
import 'package:get_it/get_it.dart';

abstract class PaymentService {
  void pay(double amount);
}

class StripeService implements PaymentService {

import 'dart:async';

class EventBus {
  final _controller = StreamController<String>.broadcast();

  Stream<String> get stream => _controller.stream;

  void fire(String event) => _controller.add(event);
}

void main() {
  final bus = EventBus();
  bus.stream.listen((event) => print('Received: $event'));

  bus.fire('USER_REGISTERED');
  bus.fire('ORDER_PLACED');
}

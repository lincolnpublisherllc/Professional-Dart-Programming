void pay(double amount) {
    print('Paid $amount via Stripe');
  }
}

final locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton<PaymentService>(() => StripeService());
}

void main() {
  setupLocator();
  final service = locator<PaymentService>();
  service.pay(100.0);
}
This allows swapping implementations (Stripe, PayPal, Mock) without changing business logic.

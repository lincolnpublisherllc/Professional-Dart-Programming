import 'package:cloud_firestore/cloud_firestore.dart';

Future<void> main() async {
  final db = FirebaseFirestore.instance;
  await db.collection('users').add({'name': 'Alice', 'age': 30});
}

import 'package:dio/dio.dart';

void main() async {
  var dio = Dio(BaseOptions(baseUrl: 'https://api.example.com'));

  dio.interceptors.add(InterceptorsWrapper(
    onRequest: (options, handler) {
      options.headers['Authorization'] = 'Bearer TOKEN';
      return handler.next(options);
    },
  ));

  var response = await dio.get('/users');
  print(response.data);
}

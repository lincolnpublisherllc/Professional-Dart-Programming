import 'package:mongo_dart/mongo_dart.dart';

Future<void> main() async {
  var db = await Db.create('mongodb://localhost:27017/mydb');
  await db.open();

  var collection = db.collection('users');
  await collection.insertOne({'name': 'Alice', 'age': 30});

  var user = await collection.findOne({'name': 'Alice'});
  print(user);

  await db.close();
}

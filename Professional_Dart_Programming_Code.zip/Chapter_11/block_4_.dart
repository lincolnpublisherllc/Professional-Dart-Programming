import 'dart:async';

void main() {
  final stream = Stream.periodic(Duration(milliseconds: 200), (count) {
    return {'time': DateTime.now(), 'price': 100 + count};
  });

  stream.listen((data) {
    print('Market Update: ${data['time']} - Price: ${data['price']}');
  });
}

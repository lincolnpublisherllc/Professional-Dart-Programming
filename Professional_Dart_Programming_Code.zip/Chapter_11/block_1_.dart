import 'package:tflite_flutter/tflite_flutter.dart';

void main() async {
  final interpreter = await Interpreter.fromAsset('model.tflite');
  var input = [1.0, 2.0, 3.0, 4.0];
  var output = List.filled(1 * 10, 0).reshape([1, 10]);

  interpreter.run(input, output);
  print(output);
}

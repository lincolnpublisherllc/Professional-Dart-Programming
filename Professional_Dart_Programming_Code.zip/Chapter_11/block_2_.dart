import 'dart:math';

double monteCarloPi(int samples) {
  final rng = Random();
  int insideCircle = 0;
  for (var i = 0; i < samples; i++) {
    final x = rng.nextDouble();
    final y = rng.nextDouble();
    if (x * x + y * y <= 1) insideCircle++;
  }
  return 4 * insideCircle / samples;
}

void main() {
  print(monteCarloPi(1000000)); // ~3.14
}
